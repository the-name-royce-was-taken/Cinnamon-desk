{ pkgs }: {
  deps = [
    pkgs.htop
    pkgs.tigervnc
    pkgs.fluxbox
    pkgs.xfce.xfce4-terminal
    pkgs.chromium
    pkgs.python3
    pkgs.python3Packages.aiohttp
  ];
}
