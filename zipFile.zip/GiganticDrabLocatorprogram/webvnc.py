import asyncio
from aiohttp import web

async def health(request):
    return web.Response(text="VNC WebSocket Bridge Running")

async def ws_handler(request):
    ws = web.WebSocketResponse(protocols=('binary',))
    await ws.prepare(request)
    reader, writer = await asyncio.open_connection('127.0.0.1', 5900)

    async def ws_to_tcp():
        async for msg in ws:
            if msg.type == web.WSMsgType.BINARY:
                writer.write(msg.data)
                await writer.drain()
        writer.close()

    async def tcp_to_ws():
        try:
            while data := await reader.read(4096):
                await ws.send_bytes(data)
        except Exception:
            pass
        finally:
            await ws.close()

    await asyncio.gather(ws_to_tcp(), tcp_to_ws())
    return ws

app = web.Application()
app.router.add_get('/', health)
app.router.add_get('/websockify', ws_handler)
web.run_app(app, host='0.0.0.0', port=8080)
